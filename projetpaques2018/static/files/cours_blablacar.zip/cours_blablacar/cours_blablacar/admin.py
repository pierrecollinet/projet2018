# -*- coding: utf-8 -*-

from django.contrib import admin

from cours_blablacar.models import Utilisateur, Chien, Trajet, Reservation

admin.site.register(Utilisateur)
admin.site.register(Chien)
admin.site.register(Trajet)
admin.site.register(Reservation)
