# -*- coding: utf-8 -*-

# On importe la fonction render (pour afficher un template)
from django.shortcuts import render, redirect
from datetime import date, datetime

from cours_blablacar.models import Utilisateur, Trajet, Reservation
# Aide mémoire : pour convertir un string en date
# date_depart = datetime.strptime(date_depart, '%Y-%m-%d')

def base(request):
    return render(request, 'base.html', {})

def welcome(request):
    if 'user_id' in request.session:
        return render(request, 'welcome.html', {})
    else : 
        return redirect('/login')

def signup(request):
    erreurs = []
    if request.GET : 
        email = request.GET['email']
        password1=request.GET['password1']
        password2 = request.GET['password2']
        prenom = request.GET['prenom']
        #1. Email pas déjà utilisé
        users_with_this_email = Utilisateur.objects.filter(email = email)
        if len(users_with_this_email) != 0:
            erreur = "Cette adresse mail est déjà utilisée"
            erreurs.append(erreur)            
        #2. password1 == password2
        if password1 != password2:
            erreur = "Les mdp doivent être identiques"
            erreurs.append(erreur)
        #3. tous les champs sont obligatoires
        if len(email) == 0 or len(password1) == 0 or len(password2)==0 or len(prenom)==0:
            erreur = "tous les champs sont obligatoires"
            erreurs.append(erreur)
        # Si pas d'erreur 
        if len(erreurs) == 0:
            #1. On crée un nouveau user
            new_user = Utilisateur(email=email, password=password1, prenom=prenom)
            #2. On sauve le nouveau user dans la DB
            new_user.save()
            #3. On redirige vers 'login page'
            return redirect('/login')
    return render(request, 'signup.html', {"erreurs": erreurs})

def login(request):
    if 'user_id' in request.session:
        return redirect('/welcome')
    else : 
        erreurs = []
        if request.GET : 
            email = request.GET['email']
            password=request.GET['password']
            users_with_this_password_and_email = Utilisateur.objects.filter(email=email, password=password)
            if len(users_with_this_password_and_email) == 0 : 
                erreur = "mdp ou email erroné"
                erreurs.append(erreur)
            else : 
                # SI il arrive à se connecter, on crée une variable de session 'user_id' qui va contenir l'id de l'utilisateur qui vient de se connecter
                logged_user = Utilisateur.objects.get(email=email, password=password)
                request.session['user_id'] = logged_user.id
                return redirect('/welcome')     
        return render(request, 'login.html', {"erreurs":erreurs})

def logout(request):
    del request.session['user_id']
    return redirect('/login')

def proposer_trajet(request):
    if 'user_id' in request.session : 
        erreurs = []
        if request.GET : 
            today = datetime.today()
            print(today)
            marque = request.GET['marque']
            date_depart = request.GET['date_depart']
            ville_depart = request.GET['ville_depart']
            ville_arrivee = request.GET['ville_arrivee']
            capacite = request.GET['capacite']
            tarif = request.GET['tarif']
            # départ != arrivée
            if ville_depart == ville_arrivee : 
                erreur = "les villes d'arrivée et de départs doivent être différentes"
                erreurs.append(erreur)             
            # date pas dans le passé
            if date_depart : 
                date_depart = datetime.strptime(date_depart, '%Y-%m-%d')
                if today > date_depart : 
                    erreur = "Tu ne peux pas créer de trajet dans le passé"
                    erreurs.append(erreur)                  
            # le champ marque est obligatoire
            if len(marque)==0:
                erreur = "Le champ 'marque' est obligatoire"
                erreurs.append(erreur)     
            if len(erreurs)==0:
                # 0. On récupère l'utilisateur connecté 
                id_in_cookie = request.session['user_id']
                logged_user = Utilisateur.objects.get(id=id_in_cookie)
                # 1. On crée un nouveau trajet
                new_trajet = Trajet(
                                ville_depart = ville_depart,
                                ville_arrivee = ville_arrivee,
                                capacite = capacite,
                                tarif = tarif,
                                date_depart =date_depart,
                                marque = marque,
                                conducteur = logged_user
                    )
                # 2. On sauve le nouveau trajet dans la DB
                new_trajet.save()
                # 3. On redirige vers la welcome page    
                return redirect('/welcome')
        return render(request, 'proposer-trajet.html', {"erreurs":erreurs})     
    else : 
        return redirect('/login')

def chercher_trajet(request):
    all_trajets = Trajet.objects.all()
    id_in_cookie = request.session['user_id']
    logged_user = Utilisateur.objects.get(id=id_in_cookie)
    if request.GET : 
        ville_depart = request.GET['ville_depart']
        ville_arrivee = request.GET['ville_arrivee']
        tarif = request.GET['tarif']
        date_depart = request.GET['date_depart']
        if ville_depart : 
            all_trajets=all_trajets.filter(ville_depart=ville_depart)
        if ville_arrivee :
            all_trajets=all_trajets.filter(ville_arrivee=ville_arrivee)
        if tarif : 
            all_trajets=all_trajets.filter(tarif__lte=tarif)
        if date_depart : 
            all_trajets=all_trajets.filter(date_depart = date_depart)  
    return render(request, 'chercher-trajet.html', {"all_trajets":all_trajets, "logged_user":logged_user}) 

def book(request):
    if 'user_id' in request.session : 
        trajet_id = request.GET['trajet_id']
        id_in_cookie = request.session['user_id']
        logged_user = Utilisateur.objects.get(id=id_in_cookie)
        trajet = Trajet.objects.get(id=trajet_id)
        new_booking = Reservation(trajet=trajet, passager=logged_user)
        new_booking.save()
        return redirect('/welcome')
    else : 
        return redirect('/login')

def dashboard(request):
    today = date.today()
    if 'user_id' in request.session : 
        logged_user = Utilisateur.objects.get(id=request.session['user_id'])
        mes_trajets = Trajet.objects.filter(conducteur=logged_user)
        mes_reservations = Reservation.objects.filter(passager=logged_user)
        return render(request,"dashboard.html", {"mes_trajets":mes_trajets, "mes_reservations":mes_reservations, "today":today})
    else : 
        return redirect('/login')

def annuler(request):
    if 'user_id' in request.session : 
        logged_user = Utilisateur.objects.get(id=request.session['user_id'])
        reservation_id = request.GET['reservation_id']
        reservation_a_supprimer = Reservation.objects.get(id=reservation_id)
        reservation_a_supprimer.delete()
        return redirect('/dashboard')
    else : 
        return redirect('/login')