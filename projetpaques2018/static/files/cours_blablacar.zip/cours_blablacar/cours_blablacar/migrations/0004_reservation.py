# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('cours_blablacar', '0003_trajet'),
    ]

    operations = [
        migrations.CreateModel(
            name='Reservation',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('passager', models.ForeignKey(to='cours_blablacar.Utilisateur')),
                ('trajet', models.ForeignKey(to='cours_blablacar.Trajet')),
            ],
        ),
    ]
