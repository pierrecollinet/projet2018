# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('cours_blablacar', '0002_chien'),
    ]

    operations = [
        migrations.CreateModel(
            name='Trajet',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('ville_depart', models.CharField(max_length=100)),
                ('ville_arrivee', models.CharField(max_length=100)),
                ('capacite', models.IntegerField()),
                ('tarif', models.IntegerField()),
                ('date_depart', models.DateField()),
                ('marque', models.CharField(max_length=100)),
                ('conducteur', models.ForeignKey(to='cours_blablacar.Utilisateur')),
            ],
        ),
    ]
