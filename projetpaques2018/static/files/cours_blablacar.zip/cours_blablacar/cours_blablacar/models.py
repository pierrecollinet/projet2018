# -*- coding: utf-8 -*-
from django.db import models

class Chien(models.Model):
    race = models.CharField(max_length=100)
    
class Utilisateur(models.Model):
    email = models.EmailField()
    password = models.CharField(max_length=100)
    prenom = models.CharField(max_length=100)
    
    def __str__(self):
        return self.email + " - " + self.prenom
    
class Trajet(models.Model):
    ville_depart = models.CharField(max_length=100)
    ville_arrivee = models.CharField(max_length=100)
    capacite = models.IntegerField()
    tarif = models.IntegerField()
    date_depart = models.DateField()
    marque = models.CharField(max_length=100)
    conducteur = models.ForeignKey(Utilisateur)
    
    def __str__(self):
        return "trajet de "+self.ville_depart+ " a "+self.ville_arrivee
    
class Reservation(models.Model):
    trajet = models.ForeignKey(Trajet)
    passager = models.ForeignKey(Utilisateur)

    def __str__(self):
        return "Reservation : " +self.trajet.ville_depart+ " a "+self.trajet.ville_arrivee
       
    
    
    
    
    
    
    